Depends on 

Numpy
Scipy
Matplotlib
H5py
DEAP >= 1.1.0
